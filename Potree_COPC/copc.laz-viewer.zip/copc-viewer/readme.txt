Filerna här behöver köras på en webbserver!
Utan webbserver så kommer inte filinläsning eller gränssnitt fungera!

Det går att starta en med python som fungerar:

$ python -m http.server 1234

Gå sedan till http://localhost:1234/pc-drop.html

För att visa punktmolnsfiler så behöver de vara i COPC format.
Enklast är att konvertera med PDAL:

$ pdal translate -i input.laz -o output.copc.laz

(PDAL kan översätta mellan flera format)

Källkod:
Webbapplikationen bygger på ett html dokument skapat av Klas Karlsson.
Applikationen använder Potree version 1.8.3 som är en "fixad" version
för att kunna visa COPC filer. Version 1.8.2 finns på GitHub, men kan
inte visa COPC filer korrekt. Några filer i "libs" katalogen är också
"fixade" då de annars har ett oönskat beteende i vissa situationer.
